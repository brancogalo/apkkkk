# 🚀 INSTALAR JÁ - Sem Complicação

## PASSO 1️⃣ - Seu PC/Notebook

### Windows/Mac/Linux:
```bash
cd desktop
npm install
npm start
```

**Pronto!** Abre automaticamente: `http://localhost:3000`

---

## PASSO 2️⃣ - Seu Android

### Opção A: APK Pronto (MAIS RÁPIDO ✅)
1. Pegue o arquivo: **app-release.apk** (já compilado)
2. Envie para seu Android (email, Telegram, etc)
3. Abra o arquivo e instale
4. ✅ Pronto!

### Opção B: Se quiser configurar o IP manualmente
1. Instale o APK (como acima)
2. Após instalar, **ligue a lanterna 5 vezes** rapidinho
3. Abre a tela de configuração
4. Digite seu IP (ex: `http://192.168.1.50:3000`)
5. Salva

---

## PASSO 3️⃣ - Dar Permissão (IMPORTANTE!)

1. Configurações → Apps → SMS Forwarder
2. Permissões → **SMS** ✅
3. Volte em Apps
4. Procure "App padrão de SMS" ou "Gerenciador de SMS"
5. Selecione **SMS Forwarder** ✅

---

## PASSO 4️⃣ - Testar

1. Envie um SMS para seu número
2. Abre a interface web: `http://seu-ip:3000`
3. ✅ SMS aparece RAPIDINHO (tempo real!)

---

## Como Saber seu IP?

**Windows:**
```
cmd → ipconfig → procura "IPv4 Address"
```

**Mac/Linux:**
```
terminal → ifconfig → procura "inet"
```

---

## ✅ Pronto!

Seu app SMS está:
- 🚀 Rodando no PC
- 📱 Recebendo SMS secretamente no Android
- 🔔 Notificando no desktop
- ⚡ Em tempo real

**Não tem notificação no Android?** ✓ Exato, é secreto!

---

## 🆘 Se não funcionar...

### SMS não chega na web?
- Certifique-se que Android e PC estão na **mesma rede WiFi**
- Verifique se você deu a permissão de SMS
- Tente enviar outro SMS

### Interface web branca?
- Acesse `http://localhost:3000` (não use IP)
- Ou `http://seu-ip-aqui:3000` (com o IP correto)

### App não intercepta SMS?
- Abra Configurações → Apps → SMS Forwarder
- Vá em Permissões → SMS → Marque ✅
- Se tiver "App SMS padrão", configure lá também

---

**Sucesso! 🎉**
