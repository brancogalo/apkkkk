#!/bin/bash

echo ""
echo "===================================="
echo " SMS Forwarder - Build APK"
echo "===================================="
echo ""

# Verifica se gradle wrapper existe
if [ ! -f "./gradlew" ]; then
    echo "❌ Gradle wrapper não encontrado!"
    echo "Certifique-se de estar na pasta raiz do projeto"
    exit 1
fi

# Torna o gradle executável
chmod +x ./gradlew

# Compilar APK de release
echo "📦 Compilando APK..."
./gradlew assembleRelease

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ APK compilado com sucesso!"
    echo "📁 Localização: app/build/outputs/apk/release/app-release.apk"
    echo ""
    echo "Próximos passos:"
    echo "1. Envie o APK para seu Android"
    echo "2. Instale"
    echo "3. Dê a permissão de SMS"
    echo "4. Abra a interface web"
    echo ""
else
    echo ""
    echo "❌ Erro na compilação!"
    exit 1
fi
