#!/usr/bin/env python3
"""
Script para gerar APK com IP pré-configurado
"""

import os
import sys
import subprocess
import re

def get_local_ip():
    """Tenta detectar o IP local automaticamente"""
    try:
        import socket
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        return ip
    except:
        return None

def update_worker_ip(ip_address):
    """Atualiza o IP no SMSForwardingWorker.kt"""
    worker_file = 'app/src/main/java/com/example/smsforwarder/SMSForwardingWorker.kt'
    
    if not os.path.exists(worker_file):
        print(f"❌ Arquivo não encontrado: {worker_file}")
        return False
    
    with open(worker_file, 'r') as f:
        content = f.read()
    
    # Substitui qualquer URL anterior por uma nova
    new_content = re.sub(
        r'val serverUrl = "http://[\d.]+:\d+"',
        f'val serverUrl = "http://{ip_address}:3000"',
        content
    )
    
    with open(worker_file, 'w') as f:
        f.write(new_content)
    
    print(f"✅ IP configurado: {ip_address}:3000")
    return True

def build_apk():
    """Compila o APK"""
    print("\n📦 Compilando APK...")
    
    # Torna o gradlew executável
    if os.path.exists('./gradlew'):
        os.chmod('./gradlew', 0o755)
    
    # Compila
    result = subprocess.run(
        ['./gradlew' if os.name != 'nt' else 'gradlew.bat', 'assembleRelease'],
        capture_output=True,
        text=True
    )
    
    if result.returncode == 0:
        print("✅ APK compilado com sucesso!")
        print("📁 Localização: app/build/outputs/apk/release/app-release.apk")
        return True
    else:
        print("❌ Erro na compilação:")
        print(result.stderr)
        return False

def main():
    print("\n" + "="*50)
    print(" 📱 SMS Forwarder - Gerador de APK")
    print("="*50 + "\n")
    
    # Detecta IP automaticamente
    auto_ip = get_local_ip()
    if auto_ip:
        print(f"🔍 IP local detectado: {auto_ip}")
    
    # Pergunta ao usuário
    ip_input = input(f"\n📍 Digite o IP ([Enter] para {auto_ip or 'padrão'}): ").strip()
    
    ip_address = ip_input or auto_ip or "192.168.1.100"
    
    # Valida IP
    if not re.match(r'^\d+\.\d+\.\d+\.\d+$', ip_address):
        print(f"❌ IP inválido: {ip_address}")
        return 1
    
    # Atualiza o IP
    if not update_worker_ip(ip_address):
        return 1
    
    # Compila o APK
    if not build_apk():
        return 1
    
    print("\n" + "="*50)
    print("✅ APK PRONTO!")
    print("="*50)
    print("\nPróximos passos:")
    print("1. Encontre o arquivo: app-release.apk")
    print("2. Envie para seu Android (email, Telegram, etc)")
    print("3. Instale no telefone")
    print("4. Dê permissão de SMS")
    print("5. Pronto! SMS chegará no seu PC")
    
    return 0

if __name__ == '__main__':
    sys.exit(main())
