@echo off
echo.
echo ====================================
echo  SMS Forwarder - Build APK
echo ====================================
echo.

REM Verifica se Android Studio está instalado
if exist "%ProgramFiles%\Android\Android Studio\bin\studio.cmd" (
    echo ✅ Android Studio encontrado
) else (
    echo ❌ Android Studio não encontrado!
    echo Instale a partir de: https://developer.android.com/studio
    pause
    exit /b 1
)

REM Cria o diretório local.properties
echo.
echo 📝 Criando configurações de build...
REM Você precisa configurar o SDK path manualmente

echo.
echo 📦 Compilando APK de release...
cd app
call gradlew.bat assembleRelease

if %errorlevel% equ 0 (
    echo.
    echo ✅ APK compilado com sucesso!
    echo 📁 Localização: app\build\outputs\apk\release\app-release.apk
    echo.
) else (
    echo.
    echo ❌ Erro na compilação!
    pause
    exit /b 1
)

pause
