# ProGuard rules for SMS Forwarder

-keep class com.example.smsforwarder.** { *; }

# OkHttp3
-keep class okhttp3.** { *; }
-keep class okio.** { *; }

# WorkManager
-keep class androidx.work.** { *; }

# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Remove logs em release
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}
