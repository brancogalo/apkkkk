package com.example.smsforwarder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsMessage
import android.util.Log
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf

class SMSReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Received_ACTION) {
            val bundle = intent.extras ?: return
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)

            for (message in messages) {
                val sender = message.originatingAddress ?: "Unknown"
                val body = message.messageBody ?: ""
                val timestamp = message.timestampMillis

                Log.d("SMSReceiver", "SMS recebido: $sender - $body")

                // Envia para o servidor via worker (sem notificações!)
                val workRequest = OneTimeWorkRequestBuilder<SMSForwardingWorker>()
                    .setInputData(
                        workDataOf(
                            "sender" to sender,
                            "body" to body,
                            "timestamp" to timestamp
                        )
                    )
                    .build()

                WorkManager.getInstance(context).enqueue(workRequest)

                // ⚠️ IMPORTANTE: Isso suprime a notificação padrão de SMS
                // abortBroadcast() - descomente para suprimir totalmente
            }
        }
    }
}
