package com.example.smsforwarder

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SetupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)

        val sharedPref = getSharedPreferences("sms_forwarder", Context.MODE_PRIVATE)
        val currentUrl = sharedPref.getString("server_url", "http://192.168.1.100:3000") ?: ""

        val ipInput = findViewById<EditText>(R.id.et_server_url)
        val saveBtn = findViewById<Button>(R.id.btn_save)
        val statusText = findViewById<TextView>(R.id.tv_status)

        ipInput.setText(currentUrl)
        statusText.text = "IP Atual: $currentUrl"

        saveBtn.setOnClickListener {
            val url = ipInput.text.toString().trim()

            if (url.isEmpty() || !url.startsWith("http")) {
                Toast.makeText(this, "URL inválida! Use: http://192.168.1.x:3000", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            sharedPref.edit().putString("server_url", url).apply()
            statusText.text = "✅ Salvo: $url"
            Toast.makeText(this, "Servidor configurado!", Toast.LENGTH_SHORT).show()

            // Fecha após 2 segundos
            Thread {
                Thread.sleep(2000)
                finish()
            }.start()
        }
    }
}
