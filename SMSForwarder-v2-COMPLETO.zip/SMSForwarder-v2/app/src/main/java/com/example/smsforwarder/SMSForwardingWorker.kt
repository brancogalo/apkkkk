package com.example.smsforwarder

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.TimeUnit

class SMSForwardingWorker(context: Context, params: WorkerParameters) :
    CoroutineWorker(context, params) {

    private val sharedPref = context.getSharedPreferences("sms_forwarder", Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    override suspend fun doWork(): Result {
        val sender = inputData.getString("sender") ?: return Result.failure()
        val body = inputData.getString("body") ?: return Result.failure()
        val timestamp = inputData.getLong("timestamp", 0L)

        return try {
            // Tenta descobrir o servidor automaticamente
            var serverUrl = discoverServer() ?: getStoredServerUrl()

            if (serverUrl == null) {
                Log.e("SMSForwarder", "❌ Servidor não encontrado! Configure via setup.")
                return Result.retry()
            }

            Log.d("SMSForwarder", "📤 Enviando para: $serverUrl")

            val jsonBody = JSONObject().apply {
                put("sender", sender)
                put("body", body)
                put("timestamp", timestamp)
            }

            val requestBody = jsonBody.toString()
                .toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("$serverUrl/api/sms")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()

            if (response.isSuccessful) {
                Log.d("SMSForwarder", "✅ SMS enviado com sucesso!")
                Result.success()
            } else {
                Log.e("SMSForwarder", "⚠️ Erro ${response.code}")
                Result.retry()
            }
        } catch (e: Exception) {
            Log.e("SMSForwarder", "❌ Erro: ${e.message}")
            e.printStackTrace()
            Result.retry()
        }
    }

    private fun discoverServer(): String? {
        return try {
            // Tenta encontrar servidor SMS Forwarder na rede via broadcast
            val socket = DatagramSocket()
            socket.broadcast = true
            socket.soTimeout = 3000

            val packet = DatagramPacket(
                "DISCOVER_SMS_SERVER".toByteArray(),
                "DISCOVER_SMS_SERVER".length,
                InetAddress.getByName("255.255.255.255"),
                3000
            )

            socket.send(packet)

            val receivePacket = DatagramPacket(ByteArray(256), 256)
            socket.receive(receivePacket)
            socket.close()

            val response = String(receivePacket.data, 0, receivePacket.length).trim()
            if (response.contains("http")) {
                Log.d("SMSForwarder", "🎯 Servidor descoberto: $response")
                saveServerUrl(response)
                return response
            }
            null
        } catch (e: Exception) {
            Log.d("SMSForwarder", "⚠️ Auto-discover falhou: ${e.message}")
            null
        }
    }

    private fun getStoredServerUrl(): String? {
        return sharedPref.getString("server_url", null)?.also {
            Log.d("SMSForwarder", "📍 Usando servidor salvo: $it")
        }
    }

    private fun saveServerUrl(url: String) {
        sharedPref.edit().putString("server_url", url).apply()
    }
}
