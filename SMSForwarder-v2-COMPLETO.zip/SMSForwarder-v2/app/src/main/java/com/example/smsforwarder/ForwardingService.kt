package com.example.smsforwarder

import android.app.Service
import android.content.Intent
import android.os.IBinder

class ForwardingService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
