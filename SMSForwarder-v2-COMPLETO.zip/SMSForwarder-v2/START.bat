@echo off
cd desktop
npm install
npm start
