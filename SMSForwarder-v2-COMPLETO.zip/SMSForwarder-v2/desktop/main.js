const { app, BrowserWindow, Menu, Notification } = require('electron');
const isDev = require('electron-is-dev');
const path = require('path');
const { spawn } = require('child_process');

let mainWindow;
let serverProcess;

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1200,
        height: 800,
        webPreferences: {
            nodeIntegration: false,
            contextIsolation: true,
            preload: path.join(__dirname, 'preload.js')
        },
        icon: path.join(__dirname, 'assets/icon.png')
    });

    // Inicia o servidor backend
    startServer();

    const startUrl = isDev 
        ? 'http://localhost:3000' 
        : `file://${path.join(__dirname, '../build/index.html')}`;
    
    mainWindow.loadURL(startUrl);

    if (isDev) {
        mainWindow.webContents.openDevTools();
    }

    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}

function startServer() {
    serverProcess = spawn('node', [path.join(__dirname, 'server.js')], {
        stdio: 'pipe'
    });

    serverProcess.stdout.on('data', (data) => {
        console.log(`[SERVER] ${data}`);
    });

    serverProcess.stderr.on('data', (data) => {
        console.error(`[SERVER ERROR] ${data}`);
    });
}

// Escuta WebSocket para notificações em tempo real
function setupWebSocket() {
    if (mainWindow && mainWindow.webContents) {
        // Pode receber eventos do servidor
        mainWindow.webContents.on('did-finish-load', () => {
            mainWindow.webContents.send('server-ready', {
                message: 'Servidor iniciado!'
            });
        });
    }
}

app.on('ready', createWindow);

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
    if (serverProcess) {
        serverProcess.kill();
    }
});

app.on('activate', () => {
    if (mainWindow === null) {
        createWindow();
    }
});

// Menu
function createMenu() {
    const template = [
        {
            label: '📱 SMS Forwarder',
            submenu: [
                {
                    label: 'Atualizar',
                    accelerator: 'CmdOrCtrl+R',
                    click: () => {
                        if (mainWindow) mainWindow.reload();
                    }
                },
                {
                    label: 'Sair',
                    accelerator: 'CmdOrCtrl+Q',
                    click: () => {
                        app.quit();
                    }
                }
            ]
        },
        {
            label: 'Exibir',
            submenu: [
                {
                    label: 'DevTools',
                    accelerator: 'CmdOrCtrl+I',
                    click: () => {
                        if (mainWindow) mainWindow.webContents.openDevTools();
                    }
                }
            ]
        }
    ];

    const menu = Menu.buildFromTemplate(template);
    Menu.setApplicationMenu(menu);
}

app.on('ready', createMenu);

// Função para enviar notificação (chamada pelo servidor)
function showNotification(sender, body) {
    if (mainWindow) {
        new Notification({
            title: `📱 SMS de ${sender}`,
            body: body,
            icon: path.join(__dirname, 'assets/icon.png'),
            sound: true
        }).show();
    }
}

// Exporta para ser usado no servidor
module.exports = { showNotification };
