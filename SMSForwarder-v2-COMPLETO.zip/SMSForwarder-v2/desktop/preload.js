const { ipcRenderer } = require('electron');

// Expõe funções seguras para o renderer
window.api = {
    // Recebe eventos do main process
    onServerReady: (callback) => ipcRenderer.on('server-ready', (event, data) => callback(data)),
    
    // Envia eventos para o main process
    notify: (title, message) => ipcRenderer.send('notify', { title, message })
};
