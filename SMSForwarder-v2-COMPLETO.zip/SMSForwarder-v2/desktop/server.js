const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

// Banco de dados SQLite
const db = new sqlite3.Database('./messages.db', (err) => {
    if (err) console.error('❌ Erro ao conectar ao BD:', err);
    else console.log('✅ Conectado ao banco de dados SQLite');
});

// Criar tabela de mensagens
db.run(`
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender TEXT NOT NULL,
        body TEXT NOT NULL,
        timestamp INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        read INTEGER DEFAULT 0
    )
`);

// Criar servidor HTTP
const server = http.createServer(app);

// WebSocket para notificações em tempo real
const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
    console.log('🔗 Cliente WebSocket conectado');
    ws.send(JSON.stringify({ type: 'connected', message: 'Conectado ao servidor!' }));

    ws.on('close', () => {
        console.log('❌ Cliente WebSocket desconectado');
    });
});

// Função para notificar todos os clientes
function broadcastMessage(message) {
    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(message));
        }
    });
}

// ===== ROTAS DA API =====

// Receber SMS do Android
app.post('/api/sms', (req, res) => {
    const { sender, body, timestamp } = req.body;

    if (!sender || !body) {
        return res.status(400).json({ error: 'Dados inválidos' });
    }

    db.run(
        'INSERT INTO messages (sender, body, timestamp) VALUES (?, ?, ?)',
        [sender, body, timestamp],
        function(err) {
            if (err) {
                console.error('❌ Erro ao salvar mensagem:', err);
                return res.status(500).json({ error: 'Erro ao salvar' });
            }

            const messageId = this.lastID;
            const newMessage = {
                id: messageId,
                sender,
                body,
                timestamp,
                created_at: new Date().toISOString(),
                read: 0
            };

            console.log(`📨 SMS recebido de ${sender}`);
            console.log(`   Mensagem: ${body}`);

            // Notifica todos os clientes WebSocket
            broadcastMessage({
                type: 'new_message',
                message: newMessage
            });

            // Se tiver Electron, mostra notificação desktop
            if (process.env.ELECTRON_APP) {
                showDesktopNotification(sender, body);
            }

            res.json({ success: true, id: messageId });
        }
    );
});

// Obter todas as mensagens
app.get('/api/messages', (req, res) => {
    db.all(
        'SELECT * FROM messages ORDER BY timestamp DESC',
        (err, rows) => {
            if (err) {
                return res.status(500).json({ error: 'Erro ao buscar mensagens' });
            }
            res.json(rows);
        }
    );
});

// Obter mensagens não lidas
app.get('/api/messages/unread', (req, res) => {
    db.all(
        'SELECT * FROM messages WHERE read = 0 ORDER BY timestamp DESC',
        (err, rows) => {
            if (err) {
                return res.status(500).json({ error: 'Erro ao buscar mensagens' });
            }
            res.json(rows);
        }
    );
});

// Marcar mensagem como lida
app.put('/api/messages/:id/read', (req, res) => {
    const { id } = req.params;

    db.run(
        'UPDATE messages SET read = 1 WHERE id = ?',
        [id],
        (err) => {
            if (err) {
                return res.status(500).json({ error: 'Erro ao atualizar' });
            }

            broadcastMessage({
                type: 'message_read',
                id: parseInt(id)
            });

            res.json({ success: true });
        }
    );
});

// Deletar mensagem
app.delete('/api/messages/:id', (req, res) => {
    const { id } = req.params;

    db.run(
        'DELETE FROM messages WHERE id = ?',
        [id],
        (err) => {
            if (err) {
                return res.status(500).json({ error: 'Erro ao deletar' });
            }

            broadcastMessage({
                type: 'message_deleted',
                id: parseInt(id)
            });

            res.json({ success: true });
        }
    );
});

// Deletar todas as mensagens
app.delete('/api/messages', (req, res) => {
    db.run('DELETE FROM messages', (err) => {
        if (err) {
            return res.status(500).json({ error: 'Erro ao deletar' });
        }

        broadcastMessage({
            type: 'all_messages_deleted'
        });

        res.json({ success: true });
    });
});

// Estatísticas
app.get('/api/stats', (req, res) => {
    db.get(
        'SELECT COUNT(*) as total, SUM(CASE WHEN read = 0 THEN 1 ELSE 0 END) as unread FROM messages',
        (err, row) => {
            if (err) {
                return res.status(500).json({ error: 'Erro ao buscar stats' });
            }
            res.json(row || { total: 0, unread: 0 });
        }
    );
});

// Servir a interface web
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Iniciar servidor
server.listen(PORT, '0.0.0.0', () => {
    console.log(`\n🚀 Servidor rodando em http://localhost:${PORT}`);
    console.log(`🔗 WebSocket habilitado`);
    console.log(`📱 Configure seu Android para: http://[seu-ip-aqui]:${PORT}`);
});

function showDesktopNotification(sender, body) {
    try {
        const { Notification } = require('electron');
        new Notification({
            title: `📱 SMS de ${sender}`,
            body: body,
            sound: true
        }).show();
    } catch (e) {
        // Electron não disponível
    }
}

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n⛔ Encerrando servidor...');
    db.close();
    server.close();
    process.exit(0);
});
